# Bank Marketing Subscription Prediction

## a. Problem statement

The project evaluates five machine-learning classification models for predicting whether a bank customer subscribes to a term deposit (`y` = yes/no) using customer and campaign attributes. The Streamlit application evaluates saved models on a user-uploaded test CSV. It does not retrain models on uploaded data.

## b. Dataset description

- **Dataset:** UCI Bank Marketing (`bank-full.csv`)
- **Source:** UCI Machine Learning Repository, Bank Marketing dataset: https://archive.ics.uci.edu/dataset/222/bank+marketing
- **Dataset size:** 45,211 records and 17 original columns (16 candidate inputs plus target).
- **Target:** `y` (whether the client subscribed to a term deposit).
- **Leakage control:** `duration` was excluded because it is only known after the call and can make a prediction unrealistically easy.
- **Final input features:** 15 (6 numerical and 9 categorical).
- **Split:** Stratified 80/20 train-test split with `random_state=42`; 36,168 training rows and 9,043 test rows.
- **Preprocessing:** `StandardScaler` for numerical columns and `OneHotEncoder(handle_unknown='ignore')` for categorical columns. The preprocessor was fitted on training data only. The transformed feature matrix contains 50 columns.
- **Class balance:** The target is imbalanced, with approximately 88.3% `no` and 11.7% `yes`.

## c. GitHub Repository Link

Add the public GitHub repository URL here after creating the repository.

## d. Models used and evaluation

All five classifiers were trained using the same training split and evaluated on the same held-out test split. Metrics below are from the saved baseline evaluation results.

| ML Model | Accuracy | AUC | Precision | Recall | F1 | MCC |
|---|---:|---:|---:|---:|---:|---:|
| Logistic Regression | 0.8933 | 0.7717 | 0.6632 | 0.1786 | 0.2815 | 0.3065 |
| Decision Tree | 0.8309 | 0.6132 | 0.2982 | 0.3289 | 0.3128 | 0.2170 |
| K-Nearest Neighbors | 0.8874 | 0.7027 | 0.5529 | 0.1975 | 0.2911 | 0.2833 |
| Gaussian Naive Bayes | 0.8452 | 0.7514 | 0.3708 | 0.4641 | 0.4123 | 0.3271 |
| Linear SVM | 0.8932 | 0.7682 | 0.6513 | 0.1871 | 0.2907 | 0.3101 |

### Observations on model performance

| Model | Observation |
|---|---|
| Logistic Regression | Highest accuracy, AUC and precision among the five baseline models. Its recall and F1 are low, indicating that it misses many actual subscriptions. |
| Decision Tree | Lowest accuracy, AUC and MCC in this comparison. It has higher recall than Logistic Regression, KNN and Linear SVM, but its precision is low. |
| K-Nearest Neighbors | Accuracy is relatively high, but recall and F1 remain low. It does not identify the positive subscription class as effectively as Gaussian Naive Bayes. |
| Gaussian Naive Bayes | Highest recall, F1 and MCC. It detects more subscribers, although its precision and accuracy are lower than the top accuracy models. |
| Linear SVM | Accuracy and AUC are close to Logistic Regression. Precision is also high, but recall and F1 are comparatively low. |

### Overall winner for this dataset

Gaussian Naive Bayes is the strongest overall choice when balancing positive-class detection and the combined metrics, because it has the highest recall (0.4641), F1 (0.4123) and MCC (0.3271). If accuracy or precision is the primary objective, Logistic Regression performs best. The target-class imbalance should be considered when interpreting accuracy.

## Streamlit application

The application provides: (1) CSV upload, (2) a model-selection dropdown, (3) accuracy, AUC, precision, recall, F1 and MCC, and (4) a confusion matrix and classification report. The uploaded CSV must include the 15 input columns and target column `y`. The app loads the saved preprocessor and classifier artifacts and does not retrain them.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Repository contents

- `app.py` — Streamlit application source code
- `requirements.txt` — pinned Python dependencies
- `README.md` — project and evaluation documentation
- `test_data.csv` — held-out test data for app evaluation
- `preprocessor.joblib` — fitted preprocessing pipeline
- `metadata.joblib` — feature and target metadata
- `baseline_metrics.csv` — saved baseline metrics
- `models/` — five saved trained classifiers

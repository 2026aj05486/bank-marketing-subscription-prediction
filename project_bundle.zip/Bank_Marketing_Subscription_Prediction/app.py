import joblib
import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    matthews_corrcoef, roc_auc_score, confusion_matrix,
    classification_report,
)
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
MODEL_DIR = BASE_DIR / "models"

st.set_page_config(page_title="Bank Marketing Subscription Prediction", page_icon="📊", layout="wide")
st.title("Bank Marketing Subscription Prediction")
st.write(
    "Evaluate five previously trained classification models on an uploaded "
    "Bank Marketing test dataset. Models are loaded from saved artifacts; "
    "the application does not retrain them."
)

@st.cache_resource
def load_artifacts():
    preprocessor = joblib.load(BASE_DIR / "preprocessor.joblib")
    metadata = joblib.load(BASE_DIR / "metadata.joblib")
    model_files = {
        "Logistic Regression": "logistic_regression.joblib",
        "Decision Tree": "decision_tree.joblib",
        "K-Nearest Neighbors": "knn.joblib",
        "Gaussian Naive Bayes": "gaussian_naive_bayes.joblib",
        "Linear SVM": "linear_svm.joblib",
    }
    models = {name: joblib.load(MODEL_DIR / filename) for name, filename in model_files.items()}
    return preprocessor, metadata, models

try:
    preprocessor, metadata, models = load_artifacts()
except Exception as exc:
    st.error(f"Could not load the saved model artifacts: {exc}")
    st.stop()

st.sidebar.header("Model Selection")
selected_model = st.sidebar.selectbox("Choose a classification model", list(models.keys()))
st.sidebar.caption("All five trained models are available.")

feature_columns = metadata["feature_columns"]
required_columns = feature_columns + ["y"]

st.subheader("Upload Test Dataset")
uploaded_file = st.file_uploader("Choose a CSV file", type=["csv"])
if uploaded_file is None:
    st.info("Upload a CSV containing the 15 input features and the actual target column `y`.")
    st.stop()

try:
    data = pd.read_csv(uploaded_file)
except Exception as exc:
    st.error(f"Could not read the uploaded CSV: {exc}")
    st.stop()

missing = [col for col in required_columns if col not in data.columns]
if missing:
    st.error("The uploaded CSV is missing required columns: " + ", ".join(missing))
    st.stop()
if data.empty:
    st.error("The uploaded CSV contains no rows.")
    st.stop()

X = data[feature_columns].copy()
y_raw = data["y"].astype(str).str.strip().str.lower()
if not y_raw.isin(["yes", "no", "0", "1"]).all():
    st.error("Target column `y` must contain only yes/no or 0/1 values.")
    st.stop()
y_true = y_raw.map({"no": 0, "yes": 1, "0": 0, "1": 1}).astype(int)

try:
    X_processed = preprocessor.transform(X)
    model = models[selected_model]
    y_pred = model.predict(X_processed)
    if hasattr(model, "predict_proba"):
        y_score = model.predict_proba(X_processed)[:, 1]
    elif hasattr(model, "decision_function"):
        y_score = model.decision_function(X_processed)
    else:
        y_score = None
except Exception as exc:
    st.error(f"Model evaluation failed: {exc}")
    st.stop()

accuracy = accuracy_score(y_true, y_pred)
precision = precision_score(y_true, y_pred, zero_division=0)
recall = recall_score(y_true, y_pred, zero_division=0)
f1 = f1_score(y_true, y_pred, zero_division=0)
mcc = matthews_corrcoef(y_true, y_pred)
auc = roc_auc_score(y_true, y_score) if y_score is not None and y_true.nunique() == 2 else float("nan")

st.subheader(f"Evaluation Results — {selected_model}")
cols = st.columns(6)
metric_values = [
    ("Accuracy", accuracy), ("AUC", auc), ("Precision", precision),
    ("Recall", recall), ("F1 Score", f1), ("MCC", mcc),
]
for col, (label, value) in zip(cols, metric_values):
    col.metric(label, "N/A" if pd.isna(value) else f"{value:.4f}")

st.caption(f"Evaluated {len(data):,} rows. No model training was performed.")
left, right = st.columns(2)
with left:
    st.subheader("Confusion Matrix")
    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    fig, ax = plt.subplots(figsize=(5, 4))
    ax.imshow(cm)
    ax.set_xticks([0, 1], labels=["Predicted No", "Predicted Yes"])
    ax.set_yticks([0, 1], labels=["Actual No", "Actual Yes"])
    ax.set_xlabel("Prediction")
    ax.set_ylabel("Actual")
    ax.set_title("Confusion Matrix")
    for (i, j), value in __import__("numpy").ndenumerate(cm):
        ax.text(j, i, str(value), ha="center", va="center")
    fig.tight_layout()
    st.pyplot(fig)
    plt.close(fig)
with right:
    st.subheader("Classification Report")
    report = classification_report(y_true, y_pred, labels=[0, 1], target_names=["No subscription", "Subscription"], output_dict=True, zero_division=0)
    st.dataframe(pd.DataFrame(report).transpose().round(4), use_container_width=True)

with st.expander("Preview uploaded data"):
    st.dataframe(data.head(20), use_container_width=True)
